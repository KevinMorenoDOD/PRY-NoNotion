create function enforce_task_list_capacity() returns trigger
    language plpgsql
as
$$
DECLARE
    list_capacity INT;
    active_count  BIGINT;
BEGIN
    SELECT capacity INTO list_capacity
    FROM task_lists
    WHERE id = NEW.list_id;

    IF list_capacity IS NULL THEN
        RETURN NEW;
    END IF;

    SELECT count(*) INTO active_count
    FROM tasks
    WHERE list_id = NEW.list_id
      AND deleted_at IS NULL;

    IF active_count >= list_capacity THEN
        RAISE EXCEPTION 'task list % has reached its capacity of % tasks', NEW.list_id, list_capacity;
    END IF;

    RETURN NEW;
END;
$$;

alter function enforce_task_list_capacity() owner to nonotion;

